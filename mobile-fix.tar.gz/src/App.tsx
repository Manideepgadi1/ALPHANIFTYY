import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Header from './components/Header';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';
import ViewportToggle from './components/ViewportToggle';

import HomePage from './pages/HomePage';
import ExploreBasketsPage from './pages/ExploreBasketsPage';
import BasketDetailsPage from './pages/BasketDetailsPage';
import SIPCalculatorPage from './pages/SIPCalculatorPage';
import LumpsumCalculatorPage from './pages/LumpsumCalculatorPage';
import GoalCalculatorPage from './pages/GoalCalculatorPage';
import ExploreFundsPage from './pages/ExploreFundsPage';
import MutualFundExplorerPage from './pages/MutualFundExplorerPage';
import FundComparisonPage from './pages/FundComparisonPage';
import FundDetailsPage from './pages/FundDetailsPageClean';
import CartPage from './pages/CartPage';
import WatchlistPage from './pages/WatchlistPage';
import SignInPage from './pages/SignInPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import CalculatorHubPage from './pages/CalculatorHubPage';
import NotFoundPage from './pages/NotFoundPage';
import MyBasketsPage from './pages/MyBasketsPage';
import PortfolioSummaryPage from './pages/PortfolioSummaryPage';
import TransactionPage from './pages/TransactionPage';
import HelpFAQPage from './pages/HelpFAQPage';
import InvestmentGuidePage from './pages/InvestmentGuidePage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import TermsPage from './pages/TermsPage';
import BasketCompareToolPage from './pages/BasketCompareToolPage';
import RiskProfileQuizPage from './pages/RiskProfileQuizPage';
import PortfolioDashboardPage from './pages/PortfolioDashboardPage';
import EducationalHubPage from './pages/EducationalHubPage';
// import PMSScreenerPage from './pages/PMSScreenerPage';

import { CartProvider } from './context/CartContext';

const App: React.FC = () => {
  return (
    <CartProvider>
      <Router 
        basename={import.meta.env.BASE_URL}
        future={{
          v7_startTransition: true,
          v7_relativeSplatPath: true
        }}
      >
        <ScrollToTop />
        <ViewportToggle />
        <div className="flex flex-col min-h-screen">
          <Header />

          <main className="flex-1">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/explore-baskets" element={<ExploreBasketsPage />} />
              <Route path="/basket-details/:id" element={<BasketDetailsPage />} />

              {/* Calculators */}
              <Route path="/calculators" element={<CalculatorHubPage />} />
              <Route path="/calculators/sip" element={<SIPCalculatorPage />} />
              <Route path="/calculators/lumpsum" element={<LumpsumCalculatorPage />} />
              <Route path="/calculators/goal" element={<GoalCalculatorPage />} />

              {/* Funds */}
              <Route path="/explore-funds" element={<ExploreFundsPage />} />
              <Route path="/fund-explorer" element={<MutualFundExplorerPage />} />
              <Route path="/fund-comparison" element={<FundComparisonPage />} />
              <Route path="/fund/:id" element={<FundDetailsPage />} />
              {/* <Route path="/pms-screener" element={<PMSScreenerPage />} /> */}

              {/* Cart & Auth */}
              <Route path="/cart" element={<CartPage />} />
              <Route path="/watchlist" element={<WatchlistPage />} />
              <Route path="/sign-in" element={<SignInPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/dashboard" element={<DashboardPage />} />
              
              {/* User Portfolio */}
              <Route path="/my-baskets" element={<MyBasketsPage />} />
              <Route path="/portfolio" element={<PortfolioSummaryPage />} />
              <Route path="/transactions" element={<TransactionPage />} />
              <Route path="/help-faq" element={<HelpFAQPage />} />
              
              {/* Resource Pages */}
              <Route path="/investment-guide" element={<InvestmentGuidePage />} />
              <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
              <Route path="/terms" element={<TermsPage />} />
              
              {/* New Features */}
              <Route path="/compare-baskets" element={<BasketCompareToolPage />} />
              <Route path="/risk-quiz" element={<RiskProfileQuizPage />} />
              <Route path="/portfolio-dashboard" element={<PortfolioDashboardPage />} />
              <Route path="/learn" element={<EducationalHubPage />} />

              {/* 404 */}
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </main>

          <Footer />
        </div>
      </Router>
    </CartProvider>
  );
};

export default App;